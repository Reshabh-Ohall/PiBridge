Placeholder for hardware files.
