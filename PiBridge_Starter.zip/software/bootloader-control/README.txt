Placeholder for software/bootloader-control files.
