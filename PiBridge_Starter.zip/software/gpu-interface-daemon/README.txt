Placeholder for software/gpu-interface-daemon files.
