Placeholder for images files.
