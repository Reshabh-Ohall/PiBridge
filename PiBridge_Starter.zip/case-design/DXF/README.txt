Placeholder for case-design/DXF files.
