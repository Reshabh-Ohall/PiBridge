Placeholder for case-design/STL files.
